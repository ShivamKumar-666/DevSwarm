---
name: system-design-architect
description: Produce complete, production-grade system designs with Excalidraw-compatible Mermaid diagrams, rigorous database and tech-stack selection, capacity estimation, and explicit trade-off analysis. Use this skill whenever the user asks to design a system, architect a service or platform, choose a database or tech stack, plan for scale, draw an architecture diagram, create a High-Level Design (HLD) or Low-Level Design (LLD), prepare for a system design interview, or mentions Mermaid/Excalidraw diagrams for architecture. Also trigger for requests like "how would you build X", "design the backend for X", "what database should I use", or "make an architecture diagram I can edit".
---

# System Design Architect

Produce system designs that an engineer could actually build from: explicit requirements, honest capacity math, justified technology choices, diagrams that can be edited in Excalidraw, and trade-offs stated out loud instead of hidden.

## Core ideology

These principles govern every design produced with this skill:

1. **Boring technology wins by default.** Choose the simplest, most battle-tested option that meets requirements (PostgreSQL before a niche database, a monolith before microservices, a queue before an event-sourcing platform). Novelty must be justified by a requirement, never by fashion.
2. **Design for the stated scale, note the next order of magnitude.** Do not build for 100M users when the requirement is 10K. Instead, state clearly what breaks first when load grows 10x and what the migration path is.
3. **Every choice is a trade-off.** Never present a decision without saying what was given up. "We chose X" is incomplete; "We chose X, accepting Y cost, because Z requirement dominates" is a design decision.
4. **Data outlives code.** Get the data model, ownership boundaries, and consistency requirements right first; services and APIs are easier to change than schemas and stored data.
5. **Failure is a requirement, not an afterthought.** Every design must answer: what happens when a dependency is down, a message is duplicated, a node dies mid-write, or a region disappears.
6. **Make the implicit explicit.** State assumptions (traffic, read/write ratio, payload sizes, consistency needs) as numbers, even rough ones. A wrong number invites correction; a missing number hides risk.

## Workflow

Follow these phases in order. For quick questions ("which DB for X?"), jump straight to the relevant deep-dive and reference file, but still state assumptions and trade-offs.

### Phase 1 — Requirements

Extract or ask for (if genuinely ambiguous, ask at most one focused round of questions; otherwise state assumptions and proceed):

- **Functional**: core user journeys, must-have vs nice-to-have features.
- **Non-functional**: expected users/DAU, requests per second, latency targets (p50/p99), availability target (99.9% vs 99.99% changes the design), durability, consistency needs per operation, compliance/data-residency.
- **Constraints**: team size and skills, budget, deadline, existing stack, build-vs-buy appetite.

### Phase 2 — Capacity estimation (back-of-envelope)

Do the math before drawing boxes. Estimate:

- QPS: `DAU × actions/user/day ÷ 86,400`, peak = 2–5× average.
- Storage: `writes/day × payload size × retention days × replication factor`.
- Bandwidth: `QPS × average payload`.
- Cache size: ~20% of hot data (80/20 rule) as a starting point.

Useful anchors: 86,400 seconds/day; 1M requests/day ≈ 12 QPS average; a single well-tuned PostgreSQL node comfortably handles thousands of QPS on modest hardware; Redis handles ~100K+ ops/sec per node; a Kafka partition sustains tens of MB/s.

State the conclusion the numbers force. Example: "40 QPS average, 200 peak, 50 GB/year — this fits on one Postgres instance with a replica; sharding would be premature."

### Phase 3 — High-level design (with diagram)

Produce the component architecture as a **Mermaid `flowchart`** (mandatory — see Diagram rules below), covering: clients, edge (CDN/LB/API gateway), services, async paths (queues/streams), data stores, caches, third-party dependencies.

Accompany the diagram with a short walkthrough of the primary request path and the primary async path.

### Phase 4 — Deep dives

Cover each of the following that is relevant; consult the reference files for depth:

- **Data model & database selection** → read `references/database-selection.md`. Output: chosen engine(s) with justification, key tables/collections, indexes, partition/shard key if applicable, and a data-model diagram (Mermaid `erDiagram` or `classDiagram`).
- **API design**: protocol choice (REST/GraphQL/gRPC/WebSocket), key endpoints with methods and status codes, pagination, versioning, idempotency keys for mutating endpoints, rate limiting.
- **Tech stack** → read `references/tech-stack.md`. Output: a stack table (layer → choice → why → runner-up rejected and why).
- **Caching, queues, scaling, resilience** → read `references/scale-patterns.md`. Output: cache strategy with invalidation approach and TTLs, queue/stream choice with delivery semantics, and failure handling (retries, circuit breakers, DLQs, idempotency).
- **Critical flows**: for 1–3 most important or trickiest flows (e.g., payment, write path with cache invalidation), produce a Mermaid `sequenceDiagram`.
- **Security**: authn (JWT/sessions/OAuth), authz model (RBAC/ABAC), secrets management, encryption in transit and at rest, input validation, tenant isolation if multi-tenant.
- **Observability**: the three pillars (metrics, logs, traces), the 4 golden signals (latency, traffic, errors, saturation), SLOs matching the availability target, alerting on symptoms not causes.

### Phase 5 — Trade-offs, risks, and evolution

Close every design with:

- **Decision table**: each major decision → alternative considered → why rejected → what we gave up.
- **What breaks first at 10x**: name the first bottleneck and the mitigation path.
- **Single points of failure** remaining, and whether they are accepted or mitigated.
- **Open questions** the team must answer before building.

## Diagram rules (Excalidraw-compatible Mermaid)

Every design MUST include Mermaid diagrams in plain fenced code blocks so the user can copy them into Excalidraw (**Menu → More tools → Mermaid to Excalidraw**, or on the canvas: Shape menu → Mermaid). Excalidraw converts them into fully editable shapes.

**Compatibility is the hard constraint.** Excalidraw's Mermaid importer converts `flowchart`/`graph`, `sequenceDiagram`, and `classDiagram` into native editable elements. Other types (`erDiagram`, `stateDiagram`, `gantt`) import as a static image — usable, but not editable shape-by-shape. Therefore:

- **Architecture diagrams**: always `flowchart LR` or `flowchart TB`. Never draw architecture as anything else.
- **Data models**: prefer `classDiagram` (fully editable in Excalidraw) with entities as classes and relationships as associations. Offer `erDiagram` only as an optional extra and warn it imports as an image.
- **Flows/interactions**: `sequenceDiagram`.

**Syntax rules for clean conversion** (violations cause broken imports):

- Quote every label: `A["API Gateway"]`, `-->|"cache miss"|`. Unquoted labels with spaces, slashes, or parentheses break parsing.
- No emojis, no HTML tags, no `<br/>` in labels; keep labels under ~30 characters — Excalidraw does not reflow long text well.
- Use `subgraph "Name" ... end` to group tiers (Edge, Services, Data, Async). Subgraphs become editable frames/containers.
- Use shape semantics consistently: `[" "]` rectangles for services, `[(" ")]` cylinders for databases, `(" ")` rounded for external systems/clients, `{" "}` diamonds for decisions.
- Keep one diagram under ~25 nodes. If bigger, split into a context diagram plus per-domain diagrams — huge diagrams become unreadable in Excalidraw.
- Use `classDef` sparingly or not at all; heavy styling is lost on import. Structure over decoration.
- After each diagram block, add one line: *"Paste into Excalidraw via More tools → Mermaid to Excalidraw for an editable version."* (Once per response is enough if there are many diagrams.)

**Template — architecture flowchart:**

```mermaid
flowchart LR
  U("Client Apps") --> CDN["CDN"]
  CDN --> LB["Load Balancer"]
  subgraph "Services"
    LB --> GW["API Gateway"]
    GW --> S1["Auth Service"]
    GW --> S2["Core Service"]
  end
  subgraph "Data"
    S2 --> PG[("PostgreSQL")]
    S2 --> RC[("Redis Cache")]
  end
  subgraph "Async"
    S2 -->|"events"| Q["Kafka"]
    Q --> W["Workers"]
    W --> PG
  end
```

**Template — sequence diagram (write path with cache invalidation):**

```mermaid
sequenceDiagram
  participant C as Client
  participant A as API
  participant D as Postgres
  participant R as Redis
  C->>A: PUT /items/42
  A->>D: UPDATE items
  D-->>A: OK
  A->>R: DEL item:42
  A-->>C: 200 OK
```

**Template — data model as classDiagram:**

```mermaid
classDiagram
  class User {
    +uuid id
    +string email
    +timestamptz created_at
  }
  class Order {
    +uuid id
    +uuid user_id
    +int amount_cents
    +string status
  }
  User "1" --> "many" Order : places
```

## Output structure

For a full design, use this document shape (prose-first, diagrams inline where listed):

```
# [System Name] — System Design
## 1. Requirements & Assumptions        (functional, NFRs, stated numbers)
## 2. Capacity Estimation               (the math and its conclusion)
## 3. High-Level Architecture           (flowchart + walkthrough)
## 4. Data Model & Database Choice      (classDiagram + engine justification)
## 5. API Design                        (key endpoints, semantics)
## 6. Tech Stack                        (table: layer/choice/why/rejected)
## 7. Deep Dives                        (caching, queues, critical-flow sequenceDiagrams)
## 8. Security & Observability
## 9. Trade-offs, Risks & 10x Plan      (decision table, SPOFs, evolution)
```

For narrow questions, answer directly but keep the discipline: assumptions → recommendation → trade-off → what would change the answer.

## Reference files

Read these on demand during Phase 4 — do not load them for trivial questions you can answer from the summaries above:

- `references/database-selection.md` — full decision framework: workload classification, engine comparison (relational, document, KV, wide-column, graph, time-series, search, vector), indexing, sharding/partitioning, replication and consistency, CAP/PACELC in practice, polyglot patterns, migration paths.
- `references/tech-stack.md` — API protocol selection, language/framework guidance by context, messaging systems compared, compute platform choice (serverless vs containers vs VMs), observability stack, and a "default stack" for common scenarios.
- `references/scale-patterns.md` — caching patterns and invalidation, load balancing, rate limiting, queue semantics and idempotency, outbox/saga patterns, resilience (retries, circuit breakers, bulkheads), sharding strategies, multi-region, and estimation cheat sheet.

## Anti-patterns to actively avoid

- Recommending microservices, Kubernetes, Kafka, or NoSQL as defaults without a requirement forcing them.
- Diagrams with unquoted labels, emojis, or 40+ nodes (breaks or clutters Excalidraw import).
- "It depends" without then depending on something: always land on a recommendation given the stated assumptions.
- Capacity numbers pulled from nowhere — show the arithmetic.
- Ignoring the write path, cache invalidation, or failure modes because the happy path looks clean.
- Presenting the design as final: always include the 10x-growth and open-questions sections.
