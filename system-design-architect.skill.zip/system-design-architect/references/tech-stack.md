# Tech Stack Selection

Use this when recommending languages, frameworks, protocols, messaging, compute platforms, and supporting infrastructure. The governing rule: **team familiarity and operational simplicity outweigh benchmark deltas** for almost every product. Recommend what the team can run at 3 a.m.

## API protocol

| Protocol | Choose when | Avoid when |
|---|---|---|
| REST (JSON/HTTP) | Public APIs, CRUD-shaped domains, broad client compatibility. The default. | Chatty clients needing many joined resources per screen |
| GraphQL | Many client types with divergent data needs; frontend-driven teams; aggregating several backends | Small teams (adds server complexity: N+1 resolvers, caching, query cost limits); simple CRUD |
| gRPC | Service-to-service calls; low latency; strong contracts (protobuf); streaming; polyglot backends | Browser-facing APIs (needs grpc-web proxy); public third-party APIs |
| WebSocket / SSE | Real-time push: chat, live dashboards, collaborative editing. SSE if one-directional (simpler, plain HTTP, auto-reconnect) | Anything a poll every 30s would satisfy |
| Webhooks | Notifying external consumers of events | — always pair with signature verification, retries with backoff, and an idempotent receiver |

REST discipline: plural nouns (`/orders/{id}`), proper verbs and status codes (201 create, 204 delete, 409 conflict, 422 validation), cursor pagination for large/changing sets (offset pagination breaks under concurrent writes), version via URL prefix (`/v1/`) or header, `Idempotency-Key` header on all POSTs with side effects, rate-limit headers.

## Language / framework by context

There is no best language; there is a best language *for this team and workload*:

- **TypeScript (Node/NestJS/Fastify, or Bun)**: full-stack teams sharing types end-to-end, I/O-bound APIs, fastest iteration. Watch: CPU-bound work blocks the event loop — offload to workers.
- **Python (FastAPI/Django)**: AI/ML-adjacent products (ecosystem gravity), data pipelines, rapid backends. FastAPI for async APIs + pydantic contracts; Django when you want batteries (admin, ORM, auth) for CRUD-heavy products. Watch: GIL for CPU-bound; scale out with more processes/workers.
- **Go**: infrastructure services, high-concurrency network servers, single-binary deploys, teams valuing simplicity + performance. The sweet spot for most "we outgrew our scripting language" migrations.
- **Rust**: performance-critical hot paths, memory-constrained systems, correctness-critical components (storage engines, proxies). Highest cost to team velocity — adopt for components, not by default for whole products.
- **JVM (Java/Spring, Kotlin)**: large enterprise teams, mature ecosystem, heavy integration landscapes.

Frontend default: React/Next.js (ecosystem, hiring) unless the team has committed elsewhere; SSR/ISR for content-heavy or SEO-sensitive surfaces, SPA for app-like tools.

## Messaging & streaming

Decide by **semantics needed**, not popularity:

| Need | Choice |
|---|---|
| Background jobs, task queue, per-message ack, retries, DLQ | RabbitMQ, or cloud-native SQS; Redis-backed (BullMQ/Celery/Sidekiq) fine at small scale if Redis already exists |
| High-throughput event log, replay, multiple independent consumers, stream processing, CDC | Kafka (or Redpanda for Kafka API with less ops) |
| Simple pub/sub fan-out, serverless | SNS+SQS, Google Pub/Sub |
| Very low latency in-process-ish messaging | NATS |

Key semantics to state in every design: delivery guarantee (at-least-once is the realistic default → **consumers must be idempotent**), ordering (Kafka: per-partition only — choose partition key accordingly), and DLQ + replay strategy for poison messages. "Exactly-once" is achieved end-to-end via idempotency keys + transactional outbox, not by a broker checkbox.

## Compute platform

Progression of complexity — pick the earliest one that fits:

1. **PaaS (Railway, Render, Fly.io, Heroku, App Runner, Cloud Run)**: default for small teams. Deploy containers, get TLS/scaling/logs. Cloud Run in particular: scale-to-zero containers, per-request billing.
2. **Serverless functions (Lambda/Cloud Functions)**: spiky/bursty traffic, event-driven glue, near-zero idle cost. Costs: cold starts (mitigate with provisioned concurrency), 15-min limits, connection-pooling pain with SQL (use RDS Proxy/pooler), harder local dev. Avoid for long-lived connections and steady high traffic (cost crossover).
3. **Kubernetes (managed: EKS/GKE/AKS)**: justified when running many services, needing advanced orchestration, or platform-engineering capacity exists. It is a tax on every deploy and every incident — do not adopt for one API and a worker.
4. **VMs / bare metal**: special needs (GPUs at cost, licensing, extreme perf control) or extreme cost optimization at scale.

Supporting choices: Terraform/OpenTofu for IaC as soon as there is more than one environment; GitHub Actions as CI default; containerize everything regardless of platform; one artifact promoted through envs (never rebuild for prod).

## Observability stack

- **Managed default**: Grafana Cloud / Datadog / New Relic — pay to skip running observability infra. Datadog is excellent and famously expensive; set ingestion budgets early.
- **Self-hosted default**: Prometheus + Grafana (metrics), Loki (logs), Tempo/Jaeger (traces), instrumented via **OpenTelemetry** — instrument once, stay vendor-portable.
- **Errors**: Sentry.
- Emit structured JSON logs with correlation/trace IDs propagated across services. Define SLOs from user-visible symptoms (availability, p99 latency) and alert on SLO burn rate, not on CPU%.

## Auth & security stack

- Don't build auth if you can avoid it: managed IdP (Auth0/Clerk/Cognito/Firebase Auth/Keycloak self-hosted) unless auth *is* the product.
- Tokens: short-lived JWT access (≤15 min) + rotating refresh tokens; server-side sessions remain a perfectly good choice for single-domain web apps (instant revocation, simpler).
- Secrets: cloud secret manager or Vault; never in env files committed anywhere; rotate on personnel change.
- Baseline: TLS everywhere, encryption at rest, least-privilege IAM, dependency scanning in CI, input validation at the boundary (schema validation: zod/pydantic), per-tenant row-level security for multi-tenant SQL.

## Default stacks by scenario

Use these as starting points, then adjust in the decision table:

- **Solo dev / MVP**: Next.js (full-stack) + Postgres (managed: Neon/Supabase/RDS) + Redis if needed + PaaS deploy + Sentry. One repo, one deploy, ship.
- **AI-heavy product**: FastAPI (Python) + Postgres/pgvector + Redis + object storage + Cloud Run/Fly + OpenTelemetry; queue heavy inference through a task queue with backpressure.
- **High-throughput event system**: Go services + Kafka/Redpanda + Postgres (truth) + ClickHouse (analytics) + Kubernetes when service count justifies it.
- **Enterprise B2B SaaS**: typed backend (Kotlin/Java/Go/TS) + Postgres with RLS multi-tenancy + SQS/RabbitMQ + managed IdP with SSO/SAML + audit log table from day one.

## Presenting the stack

Always output a table: **Layer | Choice | Why | Rejected alternative & why**. A stack recommendation without named rejected alternatives is advocacy, not engineering.
