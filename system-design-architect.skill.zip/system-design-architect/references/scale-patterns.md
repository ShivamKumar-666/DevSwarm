# Scale & Resilience Patterns

Use this for caching, load distribution, async architecture, failure handling, and growth planning. Every pattern here has a cost — apply when a number in the capacity estimate demands it, not preemptively.

## Estimation cheat sheet

- 86,400 sec/day → 1M requests/day ≈ **12 QPS avg**; peak 2–5× avg.
- Latency ladder (orders of magnitude): L1 cache ~1ns · RAM ~100ns · SSD read ~100µs · same-DC network RTT ~0.5ms · Redis GET ~0.2–1ms · indexed SQL read ~1–5ms · cross-region RTT ~50–150ms · disk seek (HDD) ~10ms.
- Throughput anchors per node: Nginx ~50K+ RPS proxying · Redis ~100K ops/s · tuned Postgres: thousands of QPS mixed, tens of thousands read-only · Kafka partition: tens of MB/s.
- Storage: 1M rows × 1 KB ≈ 1 GB (+ index overhead ~30–100%). Always multiply by replication factor (usually 3).
- Availability math: 99.9% = 8.7h down/year; 99.99% = 52min/year. Serial dependencies multiply: two 99.9% services in a request path ≈ 99.8%. Each extra nine roughly doubles-to-10x cost and complexity — challenge the requirement.

## Caching

**Where** (in order of distance from user): browser/app cache → CDN (static assets, and API responses with `Cache-Control` where safe) → API gateway/edge cache → application cache (Redis) → database internal caches.

**Patterns:**
- **Cache-aside** (default): app reads cache → on miss reads DB → populates cache with TTL. Simple, resilient (cache down = degraded, not broken).
- **Write-through**: write to cache+DB together — read-after-write consistency at write-latency cost.
- **Write-behind**: buffer writes in cache, flush async — high write absorption, risk of loss; only with durable buffer.

**Invalidation** (say this explicitly in every design): delete-on-write (`DEL key` after DB commit — delete, don't update, to avoid races) + TTL as safety net (minutes for hot mutable data, hours+ for stable data). For fan-out invalidation across services, publish invalidation events.

**Failure modes to design against:**
- **Stampede/thundering herd**: hot key expires → thousands of concurrent DB reads. Fixes: per-key mutex/single-flight, stale-while-revalidate, jittered TTLs.
- **Hot key**: one key takes disproportionate traffic → replicate the key (`key#1..N` random read), or local in-process cache with short TTL in front of Redis.
- **Penetration**: queries for nonexistent keys bypass cache → cache negative results briefly, or Bloom filter.

## Load balancing & traffic control

- L7 (ALB/Nginx/Envoy) for HTTP routing, TLS termination, retries; L4 (NLB) for raw TCP throughput/websockets at scale.
- Algorithms: round-robin default; least-connections for uneven request costs; consistent hashing when server-local state/cache matters.
- Health checks must hit a real dependency-aware endpoint (`/healthz` shallow for liveness, `/readyz` deep for routing decisions).
- **Rate limiting**: token bucket (allows bursts, the usual right answer) or sliding window; enforce at gateway per user/API-key/IP; return 429 + `Retry-After`. Distributed limiter state lives in Redis.
- **Backpressure**: bounded queues everywhere; shed load early (fast 429/503) rather than letting latency grow unboundedly — a slow system is worse than a partially unavailable one.

## Async architecture

Move anything not needed for the response off the request path (emails, thumbnails, indexing, webhooks, analytics). Request path does: validate → persist → enqueue → respond.

**Delivery reality**: brokers give at-least-once → **every consumer must be idempotent**. Techniques: natural idempotent operations (SET vs INCREMENT), dedupe table keyed by message ID (unique constraint), or `Idempotency-Key` from the client stored with the response.

**Transactional outbox** (the correct way to "write DB + publish event atomically"): in one DB transaction, write the business row AND an `outbox` row; a relay (poller or CDC via Debezium) publishes outbox rows to the broker, marking them sent. Never dual-write DB and broker directly — one will fail eventually.

**Sagas** for multi-service workflows (no distributed transactions): sequence of local transactions, each with a compensating action (refund, release inventory). Orchestration (a coordinator service/state machine — easier to reason about and debug, mild coupling) vs choreography (services react to events — decoupled, but flow becomes invisible). Default to orchestration for flows with >3 steps.

**Poison messages**: max-retry with exponential backoff → dead-letter queue → alert + manual/automated replay tooling. A DLQ nobody monitors is a data-loss device.

## Resilience patterns

- **Timeouts on every remote call** — no exceptions. Budget them: if the client gives you 2s, inner calls get fractions of it (deadline propagation).
- **Retries**: only on idempotent operations; exponential backoff **with jitter**; cap attempts (usually 3); never retry on 4xx. Retries amplify load during incidents — pair with circuit breakers.
- **Circuit breaker**: after N failures, fail fast for a cooldown, then half-open probe. Protects both caller (latency) and callee (recovery room).
- **Bulkheads**: isolate resource pools (connection pools, thread pools, queues) per dependency so one slow dependency can't exhaust everything.
- **Graceful degradation**: define per feature what "down" looks like — stale cache instead of live data, disable recommendations, queue writes for later. Write these into the design.
- **Chaos-lite**: at minimum, verify behavior when the cache is flushed, a replica lags, and the broker is unreachable.

## Scaling compute & state

- Keep services **stateless** (state in DB/Redis/object storage) → horizontal scaling is then just autoscaling on CPU/RPS/queue depth.
- Scale-out order for a typical web system: add app replicas → add cache → add read replicas → partition data → shard (see database-selection.md §5).
- **Consistent hashing** for distributing keys across nodes with minimal remapping on membership change (caches, shard routing).
- WebSockets/stateful connections: sticky routing or a pub/sub backplane (Redis) so any node can push to any connection.

## Multi-region (only when required by latency, residency, or DR targets)

- Ladder: single region + backups → warm standby (DR, minutes of RTO) → active-passive with async replication (accept RPO > 0) → active-active (hard: conflict resolution, data ownership per region, or a consensus DB like Spanner/Cockroach paying write latency).
- Route users via GeoDNS/Anycast; keep data residency by pinning tenant data to home regions.
- State the RTO (time to recover) and RPO (data loss tolerance) numbers — they decide the tier, and each tier multiplies cost.

## Fan-out problem (feeds, notifications, timelines)

- **Fan-out on write** (push to each follower's inbox at post time): fast reads, write amplification — breaks for celebrity accounts.
- **Fan-out on read** (assemble at request time): cheap writes, expensive reads.
- **Hybrid** (the standard answer): push for normal users, pull-and-merge for high-follower accounts, cache assembled results.

## Growth playbook (what to say in the "10x plan")

For the stated design, identify in order: (1) the first component to saturate (usually the database write path or a hot cache key), (2) the cheapest mitigation (index/cache/replica/vertical), (3) the structural change if that's exhausted (partition/shard/extract service), and (4) the signal/metric that tells the team it's time (e.g., "primary CPU sustained >60%", "p99 > 300ms", "replication lag > 5s"). A design that names its own breaking points is worth ten that claim to be infinitely scalable.
