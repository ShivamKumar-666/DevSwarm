# Database Selection — Decision Framework

Use this file when choosing storage engines, designing data models, or planning for data scale.

## Step 1: Classify the workload

Answer these before naming any technology:

| Question | Why it matters |
|---|---|
| Read/write ratio? | Read-heavy → replicas + cache; write-heavy → LSM engines, partitioning |
| Access pattern: by key, by query, by relationship, by time, by similarity? | This alone eliminates most categories |
| Consistency: can a read be stale? By how much? | Strong consistency shrinks the option set sharply |
| Transactions across multiple entities needed? | Multi-row ACID → relational (or spend heavily to fake it) |
| Data shape: stable schema, or heterogeneous/evolving? | Stable → relational; truly polymorphic → document |
| Size now and in 3 years? | < ~1–2 TB hot data: almost anything works; beyond: partitioning strategy matters |
| Retention/regulatory needs? | TTLs, right-to-erasure, residency affect engine and design |

## Step 2: Default answer

**PostgreSQL is the default until a specific requirement disqualifies it.** It handles relational data, JSONB documents, full-text search (decent), pub/sub (LISTEN/NOTIFY), time-series (with partitioning or TimescaleDB), and vectors (pgvector) — one operationally-understood system instead of five. A single primary with read replicas serves the vast majority of products to millions of users.

Disqualifiers that justify leaving or supplementing Postgres:

- Sustained write throughput beyond what one primary handles (~10K+ writes/sec sustained on typical hardware) → partitioned/wide-column territory.
- Hot dataset far exceeds RAM and access is key-value → dedicated KV store.
- Sub-millisecond read latency requirement → in-memory cache/store.
- Heavy analytical scans over billions of rows → columnar OLAP engine.
- Deep multi-hop relationship traversal as the core query → graph database.
- Relevance-ranked text search as a product feature → search engine.

## Step 3: Category guide

### Relational (PostgreSQL, MySQL, cloud: Aurora/AlloyDB/Cloud SQL)
- **Use for**: transactional integrity, structured data, ad-hoc queries, anything financial.
- **PostgreSQL vs MySQL**: Postgres for richer types (JSONB, arrays), extensions, stricter standards; MySQL/Vitess when the team knows it or for proven massive sharded deployments (YouTube, Slack).
- **NewSQL (CockroachDB, Spanner, TiDB, YugabyteDB)**: when you need relational semantics AND horizontal write scaling AND multi-region strong consistency. Cost: higher write latency (consensus), operational complexity, price. Do not choose for single-region apps that fit on one primary.

### Key-Value (Redis, Valkey, Memcached, DynamoDB)
- **Redis/Valkey**: cache, sessions, rate limiting, leaderboards (sorted sets), distributed locks (with care), queues (Streams). In-memory: cost scales with data size. Persistence (AOF/RDB) exists but treat it as a cache first.
- **DynamoDB**: serverless KV/document at any scale with single-digit-ms reads — if and only if you can enumerate all access patterns up front (single-table design). Painful for ad-hoc queries; excellent for known, high-scale patterns. Watch hot-partition and cost-per-RCU/WCU behavior.

### Document (MongoDB, Firestore, Couchbase)
- **Use for**: genuinely heterogeneous entities, aggregate-oriented access (load the whole document per request), rapid schema evolution.
- **Do not use because** "schema-less is faster to start" — Postgres JSONB gives that without leaving relational. Cross-document transactions and joins remain weak points.

### Wide-column (Cassandra, ScyllaDB, Bigtable)
- **Use for**: enormous write throughput, linear horizontal scaling, known query patterns (query-first modeling: one table per query), multi-DC active-active. Examples: messages, activity feeds, telemetry, time-series at scale.
- **Cost**: eventual consistency by default (tunable per-query: ONE/QUORUM/ALL), no joins, no ad-hoc queries, secondary indexes weak. ScyllaDB = Cassandra-compatible, C++, much better latency per node.

### Time-series (TimescaleDB, InfluxDB, ClickHouse, Prometheus/Mimir/VictoriaMetrics)
- **Use for**: metrics, IoT, financial ticks. Key features: time partitioning, compression, downsampling/retention policies, fast range scans.
- TimescaleDB if you want to stay in Postgres; ClickHouse when it doubles as analytics; Prometheus-family strictly for infra monitoring.

### OLAP / Columnar (ClickHouse, BigQuery, Snowflake, Redshift, DuckDB)
- **Use for**: analytics, dashboards, aggregations over billions of rows. Never point dashboards at the OLTP primary beyond trivial scale — replicate/CDC into an OLAP store.
- ClickHouse for self-hosted real-time analytics; BigQuery/Snowflake for managed elasticity; DuckDB for embedded/single-node analytics (superb for < ~100 GB).

### Graph (Neo4j, Neptune, Memgraph)
- **Use for**: queries whose depth is unknown or ≥3 hops — fraud rings, social path-finding, dependency/impact analysis, knowledge graphs.
- **Do not use** for data that merely *has* relationships — that is every dataset; SQL joins handle 1–2 hops fine.

### Search (Elasticsearch/OpenSearch, Meilisearch, Typesense)
- **Use for**: relevance ranking, fuzzy matching, faceting, log search. Always a *secondary* store fed from the source of truth (CDC or dual-write with reconciliation).
- Meilisearch/Typesense for product search with less ops burden; ES/OpenSearch for logs and heavy customization.

### Vector (pgvector, Qdrant, Milvus, Pinecone, Weaviate)
- **Use for**: semantic search, RAG, recommendations by embedding similarity.
- **pgvector first** if corpus < ~5–10M vectors and you already run Postgres. Dedicated engines (Qdrant, Milvus) for larger scale, heavy filtering + ANN combined, or high QPS. Know the index trade-off: HNSW (fast query, RAM-hungry, slow build) vs IVF (cheaper, needs tuning). Recall is tunable, not free.

### Object storage (S3/GCS/R2)
- All blobs (images, video, backups, data-lake files) go here, never in a database. Store the key/URL in the DB. Serve via CDN with signed URLs.

## Step 4: Data modeling essentials

- **Relational**: normalize to 3NF by default; denormalize only with a measured read-path reason, and document what must now be kept in sync. Use `uuid`(v7 preferred for index locality) or bigint identity keys; avoid natural keys as PKs.
- **Indexes**: every index speeds a read and taxes every write. Index FK columns and columns in frequent WHERE/ORDER BY; use composite indexes matching query prefixes (leftmost rule); partial indexes for hot subsets (`WHERE status = 'active'`); covering indexes to avoid heap fetches. Find missing/unused indexes with `pg_stat_user_indexes` and `EXPLAIN ANALYZE` — never index by superstition.
- **NoSQL modeling is query-first**: list every access pattern, then design tables/documents so each pattern is one lookup. Duplicate data deliberately; storage is cheap, cross-partition queries are not.
- **Soft deletes**: `deleted_at` timestamps beat physical deletes for auditability, but add partial indexes to keep queries fast, and plan a hard-purge job for compliance.
- **Migrations**: expand → migrate → contract. Never rename/drop a column in one deploy. Backfill in batches with throttling.

## Step 5: Scaling the database (in order — do not skip steps)

1. **Query optimization + correct indexes** (fixes 80% of "we need to shard" claims).
2. **Caching** in front (see scale-patterns.md).
3. **Connection pooling** (PgBouncer/RDS Proxy) — Postgres connections are expensive; pool at ~2–4× cores, not thousands.
4. **Read replicas** — offload reads; handle replication lag explicitly (read-your-writes: pin user to primary briefly after a write, or use LSN tracking).
5. **Vertical scaling** — unglamorous, buys years, do it.
6. **Table partitioning** (by time or tenant) within one node — prunes scans, eases retention.
7. **Sharding** — last resort. Choose the shard key by the dominant access pattern (usually `user_id`/`tenant_id`); consistent hashing or directory-based routing; accept losing cross-shard transactions and joins. Prefer a managed sharded system (Vitess, Citus, Cockroach) over hand-rolled routing.

## Consistency & replication (know what you're choosing)

- **CAP in practice**: during a partition, choose availability (serve possibly-stale data) or consistency (refuse/wait). **PACELC** adds: even without partitions, you trade latency vs consistency.
- Replication modes: async (fast, may lose acked writes on failover), sync (no loss, higher latency), quorum (Cassandra/Dynamo-style tunable: `R + W > N` gives read-your-writes).
- Per-operation thinking: a payment ledger needs strong consistency; a like-count does not. Design consistency per operation, not per system.
- Idempotency and uniqueness constraints in the database are the last line of defense against duplicate processing — use them even when the app layer "guarantees" exactly-once.

## Polyglot rule of thumb

Every additional engine costs: another failure mode, another backup/restore drill, another sync pipeline, another thing on-call must know. A typical well-run product at scale ends with: **Postgres (truth) + Redis (cache) + object storage (blobs) + one of {search, OLAP} when the product demands it**. Justify anything beyond that in the decision table.
